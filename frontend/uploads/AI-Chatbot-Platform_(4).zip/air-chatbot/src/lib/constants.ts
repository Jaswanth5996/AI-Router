export const AI_MODELS = [
  {
    id: "chatgpt",
    name: "ChatGPT",
    description: "Excels at natural language understanding and creative writing tasks.",
    specialty: "Natural language understanding, creative content generation, and detailed explanations.",
    reason: "AIR routes prompts to ChatGPT when they involve creative writing, summarization, or need for detailed explanations."
  },
  {
    id: "gemini",
    name: "Gemini",
    description: "Great for reasoning, code generation, and multimodal understanding.",
    specialty: "Reasoning, mathematical problems, and coding challenges.",
    reason: "AIR routes prompts to Gemini when they involve complex reasoning, logic problems, or code generation."
  },
  {
    id: "claude",
    name: "Claude",
    description: "Known for contextual understanding and nuanced responses.",
    specialty: "Long context windows, nuanced responses, and strong summarization.",
    reason: "AIR routes prompts to Claude when they require deep contextual understanding or analysis of long documents."
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    description: "Specialized in coding and technical problem-solving.",
    specialty: "Advanced coding, technical problem-solving, and specialized knowledge domains.",
    reason: "AIR routes prompts to DeepSeek when they involve complex technical challenges or specialized programming tasks."
  }
];

export const SAMPLE_PROMPTS = [
  {
    text: "Explain quantum computing to a 5-year-old",
    aiModel: "chatgpt"
  },
  {
    text: "Solve this math problem: Find all values of x where 2x² - 7x + 3 = 0",
    aiModel: "gemini"
  },
  {
    text: "Summarize the key arguments in favor of and against universal basic income",
    aiModel: "claude"
  },
  {
    text: "Write a recursive function to calculate Fibonacci numbers in Python",
    aiModel: "deepseek"
  }
];

export const APP_DESCRIPTION = "AIR is an intelligent chatbot that understands your prompt and routes it to the most suitable AI — whether it's ChatGPT, Gemini, Claude, or DeepSeek. It returns a smart response, rendered with real-time typing animation, and lets you know which AI powered the answer.";
